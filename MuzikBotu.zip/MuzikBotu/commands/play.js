const {SlashCommandBuilder} = require("@discordjs/builders");
const { MessageEmbed } = require("discord.js");
const { QueryType } = require("discord-player");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("play")
        .setDescription("Şarkı açmak için kullanılır.")
        .addSubcommand(subcommand => {
            subcommand
                .setName("search")
                .setDescription("Şarkı aramak için kullanılır.")
                .addStringOption(option => 
                    option
                        .setName("searchterms")
                        .setDescription("Anahtar kelimeler ile aramak için kullanılır.")
                        .setRequired(true)
                )
        })
        .addSubcommand(subcommand => {
            subcommand
                .setName("playlist")
                .setDescription("Youtube playlistlerini oynatır.")
                .addStringOption(option => {
                    option
                        .setName("url")
                        .setDescription("playlist url")
                        .setRequired(true);
                })
                
        })
        .addSubcommand(subcommand => 
            subcommand
                .setName("song")
                .setDescription("Youtube'dan şarkı oynatır.")
                .addStringOption(option => 
                    option
                    .setName("url")
                    .setDescription("Şarkı'nın urlsi")
                    .setRequired(true)
                )
        ),
    execute: async ({client, interaction}) => {
        if (!interaction.member.voice.channel)
        {
            await interaction.reply("Bu komudu kullanabilmek için bir ses kanalında olmalısın!");
            return;
        }

        const queue = await client.player.createQueue(interaction.guild);

        if (!queue.connection) await queue.connect(interaction.member.voice.channel)

        let embed = new MessageEmbed();
        if(interaction.options.getSubcommand() === "song")
        {
            let url = interaction.options.getString("url");

            const result = await client.player.search(url, {
                reqestedBy: interaction.user,
                searchEngine: QueryType.YOUTUBE_VIDEO,
            });

            if (result.tracks.length === 0)
            {
                await interaction.reply("Şarkı bulunamadı");
                return
            }

            const song = result.tracks[0]
            await queue.addTrack(song);

            embed
                .setDescription(`**[${song.title}](${song.url})** sıraya eklendi.`)
                .setThumbnail(song.thumbnail)
                .setFooter({text: `Süre: ${song.duration}`});
        }


        else if(interaction.options.getSubcommand() === "playlist")
        {
            let url = interaction.options.getString("url");

            const result = await client.player.search(url, {
                reqestedBy: interaction.user,
                searchEngine: QueryType.YOUTUBE_PLAYLIST,
            });

            if (result.tracks.length === 0)
            {
                await interaction.reply("Playlist bulunamadı");
                return
            }

            const playlist = result.playlist
            await queue.addTracks(playlist);

            embed
                .setDescription(`**[${playlist.title}](${playlist.url})** sıraya eklendi.`)
                .setThumbnail(playlist.thumbnail)
                .setFooter({text: `Süre: ${playlist.duration}`});
        }

        else if(interaction.options.getSubcommand() === "search")
        {
            let url = interaction.options.getString("searchterms");

            const result = await client.player.search(url, {
                reqestedBy: interaction.user,
                searchEngine: QueryType.AUTO,
            });

            if (result.tracks.length === 0)
            {
                await interaction.reply("Sonuç bulunamadı");
                return
            }

            const song = result.tracks[0];
            await queue.addTracks(song);

            embed
                .setDescription(`**[${song.title}](${song.url})** sıraya eklendi.`)
                .setThumbnail(song.thumbnail)
                .setFooter({text: `Süre: ${song.duration}`});
        }

        if(!queue.playing) await queue.play();

        await interaction.reply({
            embeds: [embed]
        })
    }

}