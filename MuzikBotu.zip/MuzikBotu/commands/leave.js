const {SlashCommandBuilder} = require("@discordjs/builders");
const { MessageEmbed } = require("discord.js");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("leave")
        .setDescription("Botu odadan kovar!"),
    execute: async ({client, interaction}) => {

        const queue = client.player.getQueue(interaction.guild);

        if (!queue) {
            await interaction.reply("Çalan herhangi bir parça yok.");
            return;
        }

        const currentSong = queue.current;

        queue.destroy();

        await interaction.reply("Nazikçe söylesen de çıkardım...");
    }
}