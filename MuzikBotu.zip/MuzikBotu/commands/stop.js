const {SlashCommandBuilder} = require("@discordjs/builders");
const { MessageEmbed } = require("discord.js");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("stop")
        .setDescription("Çalan şarkıyı durdurur."),
    execute: async ({client, interaction}) => {

        const queue = client.player.getQueue(interaction.guild);

        if (!queue) {
            await interaction.reply("Çalan herhangi bir parça yok.");
            return;
        }

        const currentSong = queue.current;

        queue.setStopped(true);

        await interaction.reply("Çalan şarkı duraklatıldı.");
    }
}